package Im;

import static org.junit.Assert.*;

import org.junit.Test;

public class GraphTest 
{

Graph g = new Graph();
	
	@Test
	public void allTestVertex() 
	{
//		String[] ini = {"9","10"};
//		g.initVer(ini);
//		assertEquals(2, g.sizeVer());
//		
//		String st = "9";
//		g.addVertex(st);
//		String[] exp = {"9","10","9"};
//		String[] act = g.toArrayVer();
//		assertArrayEquals(exp, act);	
//		
//		String expS = "9,10,9";
//		String actS = g.toStringVer();
//		assertEquals(expS, actS);	
//		
//		g.dellVertex(0);
//		String[] expD0= {"10","9"};
//		String[] actD0 = g.toArrayVer();
//		assertArrayEquals(expD0, actD0);
//		
//		g.dellVertex(1);
//		String[] expD1 = {"10"};
//		String[] actD1 = g.toArrayVer();
//		assertArrayEquals(expD1, actD1);
//		
//		g.clearVer();
//		assertEquals(0, g.sizeVer());
	}
	
	@Test
	public void allTestEdge() 
	{
	
	}

}
